package revija;

public class GDodavanje extends Exception {

	
	public GDodavanje(String s) {
		super(s);
	}
}
