package revija;

public class GIndeks extends Exception {

	public GIndeks(String s) {
		super(s);
	}
}
